package com.example.flutter_workshop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
